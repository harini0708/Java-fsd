package com.practiceproject;
import java.util.Iterator;
import java.util.LinkedList;
//import java.util.List;

public class Linkedlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Integer> ll=new LinkedList<Integer>();
		ll.add(10);
		ll.add(5);
		ll.add(15);
		ll.add(20);
		
		
	
	ll.addFirst(20);
		Iterator<Integer> itr=ll.iterator();
		while(itr.hasNext())
	    {
	    	System.out.println(itr.next());
	    }
		ll.addFirst(20);
		
		
	    
		

	}

}
