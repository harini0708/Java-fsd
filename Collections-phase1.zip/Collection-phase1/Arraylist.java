package com.practiceproject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    ArrayList<Integer> al=new ArrayList<Integer>();
    al.add(10);
    al.add(5);
    al.add(3);
    al.add(20);
    al.add(15);
    //sorting
    
    Collections.sort(al);
    Iterator<Integer> itr=al.iterator();
    //System.out.print("before changing");
    //elements inside list
    while(itr.hasNext())
    {
    	System.out.println(itr.next());
    }
	
	
	 while(itr.hasNext())
	    {
	    	System.out.println(itr.next());
	    }
		
	
	
	}
}
