package practiceproject2;

import java.util.Arrays;

public class Bubblesort {
	private static void sort(int[] arr, int k) {
		// TODO Auto-generated method stub
		for(int j=1;j<arr.length;j++)
		for(int i=0;i<arr.length-i;i++) {
			if(arr[i]>arr[i+1]) {
				int temp=arr[i];
				arr[i]=arr[i+1];
				arr[i+1]=temp;
						
	}

	
			
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] arr= {10,80,30,40,90};
		 int k=80;
		 sort(arr,k);
		System.out.println(Arrays.toString(arr));
		 
	}

	
}
