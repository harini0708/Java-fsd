package practiceproject2;

import java.util.Arrays;

public class Mergesort {
       public static int[] split(int[] arr){
        	if(arr.length==1)
			return arr;
        	
        	
        	int mid=arr.length/2;
        	int[] leftarray=split(Arrays.copyOfRange(arr, 0, mid));
        	int[] rightarray=split(Arrays.copyOfRange(arr, mid, arr.length));
        	
        	return merge(leftarray,rightarray);
        	
        }

	private static int[] merge(int[] firstarray,int[] secondarray) {
		// TODO Auto-generated method stub
		int[] join=new int[firstarray.length+secondarray.length];
	    int i=0,j=0,k=0;
	    while(i<firstarray.length && j<secondarray.length) {
	    	if(firstarray[i]<secondarray[j])
	    	{
	    		join[k++]=firstarray[i++];
	    	}
	    	else {
	    		join[k++]=secondarray[j++];
	    	}
	    		
	    }
	      while(i<firstarray.length)
	    	join[k++]=firstarray[i++];
	    while(j<secondarray.length)
	    	join[k++]=secondarray[j++];
	    	
		
		
		return join;
	}

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		int[] arr= {10,80,30,40,90};
		
		int[] result=split(arr);
		System.out.print(Arrays.toString(result));
		

	}

}
