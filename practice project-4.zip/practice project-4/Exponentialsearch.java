package practiceproject2;

import java.util.Arrays;

public class Exponentialsearch {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {10,20,30,40,90};
		int k=40;
		
		int outcome=search(arr,k);
		if(outcome<0)
		{
			System.out.print("element not found");
		}
		else
			System.out.print(outcome);
			
		}
	public static int   search(int[] arr,int k){
		if(arr[0]==k) return 0;
		//	System.out.print(0);
		int i=1;
		while(i<arr.length && arr[i]<=k) {
			i=i*2;}
		return Arrays.binarySearch(arr,i/2,Math.min(i,arr.length),k);
	
		
		
	}


}