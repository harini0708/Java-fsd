package practiceproject2;

public class Linearsearch {
	private static int LinearSearch(int[] arr, int k) {
		// TODO Auto-generated method stub
		for(int i=0;i<arr.length;i++)
		{
		if(arr[i]==k)
			return i;
			
		
		
	}
		return-1;
		 
}
	
  

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int[] arr= {10,20,30,40,90};
  int k=20;
  LinearSearch( arr,  k);
 System.out.print(LinearSearch( arr,  k));
  
             
      
		   
	}


	
}
