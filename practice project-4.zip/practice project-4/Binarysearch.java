package practiceproject2;

import java.util.Arrays;


public class Binarysearch {
	private static int BinarySearch(int[] arr, int target) {
		// TODO Auto-generated method stub
		int Start=0;
		int end=arr.length-1;
		
			
	
		while(Start<=end) {
			int mid=(Start+end)/2;
			if(target>arr[mid]) {
				Start=mid+1;
			}
			else if (target<arr[mid]) {
				end=mid-1;
			}
			else if (target==arr[mid]) {
				return mid;
			}
		}
		return -1;	
		}
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		  int[] arr= {10,80,30,40,90};
		  Arrays.sort(arr);
		  int k=900;
		
		 int result=(int)BinarySearch(arr,k);
		 
		 if(result==-1) {
			 System.out.print("element not present");
		 }
		 else
			 System.out.print(result);
			 
	}
}