package practiceproject2;

import java.util.Arrays;

public class Selectionsort {  
         static void insert(int[] arr){

	for(int i=1;i<arr.length;i++) {
		for(int j=i;j>0;j--) {
			if(arr[j]<arr[j-1]) {
				int temp=arr[j-1];
				arr[j-1]=arr[j];
				arr[j]=temp;
				
				
			}
		}
	}
         }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] arr= {10,80,30,40,90};
		 insert(arr);
		 System.out.print(Arrays.toString(arr));
	}
	}



