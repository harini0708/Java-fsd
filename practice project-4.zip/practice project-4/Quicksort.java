package practiceproject2;

import java.util.Arrays;

public class Quicksort {
	static void quick(int[] arr,int low ,int high) {
	
	if(low>=high) 
		return;
	int start=low;
	int end=high;
	int pivot=arr[(start+end)/2];
	
	
	while(start<=end) {
		while(arr[start]<pivot)
			start++;
		while(arr[end]>pivot)	
			end--;
		if(start<=end)
		{
			int temp=arr[start];
			arr[start]=arr[end];
			arr[end]=temp;
			start++;
			end--;
		}
		
	}
	quick(arr,low,end);
	quick(arr,start,high);
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {10,80,30,40,90};
		//System.out.print("haru");
		quick(arr,0,arr.length-1);
		System.out.print(Arrays.toString(arr));
	}

}
