package com.practiceproject;

public class Accessmodifierpublic {
	
	//public variable
	public static String name;
	//public method
	public static void Publicmethod(){
		
		System.out.println("public method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		name="public method";
		Publicmethod();
		System.out.println(name);

	}

}
