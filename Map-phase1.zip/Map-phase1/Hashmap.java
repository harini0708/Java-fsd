package com.practiceproject;
import java.util.HashMap;
public class Hashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            HashMap<Integer,String> map=new HashMap<Integer,String>();
            map.put(11, "books");
            map.put(21, "note");
            map.put(31, "pen");
            map.put(151, "box");
            map.put(112, "note");
            if (map.containsKey(11)) {
            	 
                // Mapping
                String a = map.get(11);
     
                // Printing value for the corresponding key
                System.out.println( a);
            
            }
}
}
