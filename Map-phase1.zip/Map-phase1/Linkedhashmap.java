package com.practiceproject;
import java.util.LinkedHashMap;

public class Linkedhashmap {

	public static void main(String[] args) {
		
		

				LinkedHashMap<Integer, String> hm 
					= new LinkedHashMap<Integer, String>(); 

				hm.put(3, "place"); 
				hm.put(2, "for"); 
				hm.put(1, "data"); 
				hm.put(4, "Storage"); 

				
				System.out.println("Initial Map : " + hm); 

			
				hm.remove(4); 

				// Printing the updated map 
				System.out.println("Updated Map : " + hm); 
			} 
		

	}


