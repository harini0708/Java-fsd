package com.practiceproject;
import java.util.Arrays;
public class Arrayclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		
		        // Test case 1: Creating and initializing an array
		        String[] array1 = {"hello", "this", "is", "java", "program"};
		        printArray("Array 1:",array1	);

		        // Test case 2: Accessing elements of the array
		        String elementAtIndex2 = array1[2];
		        System.out.println("Element at index 2: " + elementAtIndex2);

		        // Test case 3: Modifying elements of the array
		        array1[1] = "HELLO";
		        printArray("Modified Array 1:", array1);

		        // Test case 4: Sorting the array
		        Arrays.sort(array1);
		        printArray("Sorted Array 1:", array1);

		        // Test case 5: Copying an array
		        String[] array2 = Arrays.copyOf(array1, array1.length);
		        printArray("Copied Array 2:", array2);

		        // Test case 6: Comparing arrays
		        boolean arraysEqual = Arrays.equals(array1, array2);
		        System.out.println("Arrays equal: " + arraysEqual);
		    }

		    private static void printArray(String label, String[] array) {
		        System.out.print(label + " ");
		        for (String element : array) {
		            System.out.print(element + " ");
		        }
		        System.out.println();
		    }
		

	}


