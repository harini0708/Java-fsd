package com.practiceproject;
import java.util.HashSet;
public class Hashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> set =new HashSet<String>();
		set.add("project");
		set.add("array");
		set.add("debug");
		set.add("Storage");
		
				for(String i:set)
		{
			System.out.println(i);
		}
		System.out.println(set.getClass());
	}

}




