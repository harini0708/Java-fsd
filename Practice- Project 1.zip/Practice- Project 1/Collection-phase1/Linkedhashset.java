package com.practiceproject;
import java.util.HashSet;
import java.util.Iterator;
public class Linkedhashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> set =new HashSet<String>();
		set.add("project");
		set.add("array");
		set.add("debug");
		set.add("Storage");
		Iterator<String> itr=set.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}

}

