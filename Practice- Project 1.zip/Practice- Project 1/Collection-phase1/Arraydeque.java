package com.practiceproject;
import java.util.Deque;
import java.util.ArrayDeque;
public class Arraydeque {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deque<Integer> D =new ArrayDeque<Integer>();
		D.add(10);
		D.add(50);
		D.add(37);
		D.add(58);
		D.add(78);
		for(int i:D)
		{
			System.out.println(i);
		}
		System.out.println("size=" +D.size());
	}

}

