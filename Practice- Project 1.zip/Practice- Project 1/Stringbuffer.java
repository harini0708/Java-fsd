package com.practiceproject;

public class Stringbuffer {

	public static void main(String[] args) {
		

		        String[] s= {"print","hello","in","java"};
                
		        // Convert string to StringBuffer
		        StringBuffer sb = new StringBuffer();
                 sb.append(" "+s[0]);
                 sb.append(" "+s[1]);
                 sb.append(" "+s[2]);
                 sb.append(" "+s[3]);
                 
                 StringBuilder SB = new StringBuilder();
                 SB.append(" "+s[0]);
                 SB.append(" "+s[1]);
                 SB.append(" "+s[2]);
                 SB.append(" "+s[3]);
                 
		        // Convert string to StringBuilder
		     //   StringBuilder stringBuilder = new StringBuilder(originalString);

		        // Display the original string and the converted StringBuffer and StringBuilder
		        System.out.println("Original String: " + s);
		        System.out.println("StringBuffer: " + sb.toString());
		        System.out.println("StringBuilder: " + SB.toString());
		    }
		}

	

