package com.practiceproject;
class A{
	protected static  String name;
	protected static void Protected(){
		System.out.println("protected Access modifier");
	}
}
public class Accessmodifierprotected extends A{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          name="Protected";
          Protected();
          System.out.println(name);
	 
	}

}
