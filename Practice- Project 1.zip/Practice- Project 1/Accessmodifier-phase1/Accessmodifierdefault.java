package com.practiceproject;

public class Accessmodifierdefault {
	static String name;
	//default method
	static void  Default() {
		System.out.println("defaultaccessmodifier");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		name="default";
		Default();

		System.out.println(name);
		

	}

}
