package com.practiceproject;

public class Defaultconstructor {
	int a=10;
	boolean b;

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// // calling the default constructor 
              Defaultconstructor s =new Defaultconstructor();
           System.out.println(s.a);
           System.out.print(s.b);

}
}
