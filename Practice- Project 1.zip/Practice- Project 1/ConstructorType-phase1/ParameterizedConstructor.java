package com.practiceproject;

public class ParameterizedConstructor {
	ParameterizedConstructor(int a){
		System.out.println(a);
	}

	public static void main(String[] args) {
		new ParameterizedConstructor(10);
	}

}
