package com.practiceproject;

public class NoArgConstructor {
	    
	NoArgConstructor(){
	  
	    System.out.println("no arg constructor");
	    	
	}
	public static void main(String[] args) {
		new NoArgConstructor();
		 
		
	    
	}

}
