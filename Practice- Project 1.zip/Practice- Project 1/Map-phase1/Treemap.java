package com.practiceproject;
import java.util.TreeMap;
import java.util.Map;
public class Treemap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer,String> map=new TreeMap<Integer,String>();
		map.put(101,"roll 1");
		map.put(102,"roll 2");
		map.put(103,"roll 4");
		map.put(104,"roll 5");
		for(Map.Entry m:map.entrySet()) {
				System.out.println(m.getKey()+" "+m.getValue());
		}
		System.out.print("after removing 103 ");
		map.remove(103);      
	     
	      for(Map.Entry m:map.entrySet())  
	      {  
	          System.out.println(m.getKey()+" "+m.getValue());      
	      }  
		
	
	}

}
