package com.practiceproject;

public class Predefinedmethodcalling {
	    

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating object of the class 
		Predefinedmethodcalling obj =new Predefinedmethodcalling();
		  // predefined hashCode() method
				System.out.print(obj.hashCode());
				
	}

}
