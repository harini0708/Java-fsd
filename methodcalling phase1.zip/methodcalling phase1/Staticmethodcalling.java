package com.practiceproject;

public class Staticmethodcalling {
  static void A() {
	  System.out.print("Static method calling");
	
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           //calling static method
		A();
	}

}
