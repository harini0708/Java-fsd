package com.practiceproject;

public class Userdefinedmethod {
 void name() {
		System.out.print("User-defined-method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//calling user-defined method
		Userdefinedmethod ob=new Userdefinedmethod();
                 ob. name();
	}

}
