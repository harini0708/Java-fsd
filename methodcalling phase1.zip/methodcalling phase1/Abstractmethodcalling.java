package com.practiceproject;
   abstract class Name{
	   abstract  void name(String name); 
		   }
// Main class extending to helper class
public class Abstractmethodcalling extends Name{
	public static void main (String arg[]) {
	
		Abstractmethodcalling ob=new Abstractmethodcalling();
		 // Accessing the abstract method
		ob.name("abstract");
	}

	void name(String name)  {
		// TODO Auto-generated method stub
		System.out.print(name);
	}

}
