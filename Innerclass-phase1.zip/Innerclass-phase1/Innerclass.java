package com.practiceproject;
 class Outer{
	void show() {
		System.out.print("outer class method");
	}

public class Inner{
	  void show() {
		System.out.print("Inner class method");
	}
}
}
public class Innerclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//if class is not Static
        Outer.Inner d=new Outer().new Inner();
		d.show();
          
	}

}
