package com.practiceproject;

class Outer1{
	void show() {
		System.out.print("outer class method");
	}

public static class Inner{
	  void show() {
		System.out.print("Inner class method");
	}
}
}
public class Innerclass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      //if the class is satic
		Outer1.Inner d=new Outer1.Inner();
         d.show();
         
	}

}

