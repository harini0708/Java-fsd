package com.projectphase1;


import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;



	
	// Define a class representing a basic shape
	class Shape {
	    // Attributes
	    private String color;

	    // Constructor
	    public Shape(String color) {
	        this.color = color;
	    }

	    // Getter method for color
	    public String getColor() {
	        return color;
	    }

	    // Method to calculate area (to be overridden by subclasses)
	    public double calculateArea() {
	        return 0.0;
	    }

	    // Method to display information about the shape
	    public void displayInfo() {
	        System.out.println("This is a " + color + " shape.");
	    }
	}

	// Subclass representing a Circle
	class Circle extends Shape {
	    private double radius;

	    // Constructor
	    public Circle(String color, double radius) {
	        super(color);
	        this.radius = radius;
	    }

	    // Override the calculateArea method for circles
	    @Override
	    public double calculateArea() {
	        return Math.PI * radius * radius;
	    }

	    // Override the displayInfo method to include circle-specific information
	    @Override
	    public void displayInfo() {
	        System.out.println("This is a " + getColor() + " circle with radius " + radius + ".");
	    }
	}

	// Subclass representing a Rectangle
	class Rectangle extends Shape {
	    private double length;
	    private double width;

	    // Constructor
	    public Rectangle(String color, double length, double width) {
	        super(color);
	        this.length = length;
	        this.width = width;
	    }

	    // Override the calculateArea method for rectangles
	    @Override
	    public double calculateArea() {
	        return length * width;
	    }

	    // Override the displayInfo method to include rectangle-specific information
	    @Override
	    public void displayInfo() {
	        System.out.println("This is a " + getColor() + " rectangle with length " + length + " and width " + width + ".");
	    }
	}

	// Main class to demonstrate the program
	public class Objectorientedpillers {
	    public static void main(String[] args) {
	        // Create objects of Circle and Rectangle
	        Circle myCircle = new Circle("Red", 5.0);
	        Rectangle myRectangle = new Rectangle("Blue", 4.0, 6.0);

	        // Demonstrate polymorphism by using the base class reference
	        Shape myShape1 = myCircle;
	        Shape myShape2 = myRectangle;

	        // Display information and calculate area using polymorphism
	        myShape1.displayInfo();
	        System.out.println("Area: " + myShape1.calculateArea());

	        myShape2.displayInfo();
	        System.out.println("Area: " + myShape2.calculateArea());
	    }
	}
