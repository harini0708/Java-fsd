package com.projectphase1;
import java.util.Scanner;
public class Exceptionhandling {
	public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        try {
	            System.out.print("Enter the numerator: ");
	            int numerator = Integer.parseInt(scanner.nextLine());

	            System.out.print("Enter the denominator: ");
	            int denominator = Integer.parseInt(scanner.nextLine());

	            // Attempting division
	            int result = divideNumbers(numerator, denominator);

	            // Displaying the result
	            System.out.println("Result of division: " + result);
	        } catch (NumberFormatException e) {
	            System.out.println("Error: Please enter valid integers.");
	        } catch (ArithmeticException e) {
	            System.out.println("Error: Division by zero is not allowed.");
	        } finally {
	            // Close the scanner in the finally block to ensure it always happens
	            if (scanner != null) {
	                scanner.close();
	            }
	            System.out.println("Program execution completed.");
	        }
	    }

	    private static int divideNumbers(int numerator, int denominator) {
	        return numerator / denominator;
	    }
	}


