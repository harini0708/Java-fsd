package com.projectphase1;

//public class thread {

		
		// Example 1: Extending Thread class
		class MyThread extends Thread {
		   // @SuppressWarnings("deprecation")
			public void run() {
		        for (int i = 0; i < 5; i++) {
		            System.out.println(Thread.currentThread().getId() + " Value " + i);
		        }
		    }
		}

		// Example 2: Implementing Runnable interface
		class MyRunnable implements Runnable {
		    public void run() {
		        for (int i = 0; i < 5; i++) {
		            System.out.println(Thread.currentThread().getId()+ " Value " + i);
		        }
		    }
		}

		public class thread {
		    public static void main(String args[]) {
		        // Example 1: Extending Thread class
		        MyThread t1 = new MyThread();
		        t1.start();

		        // Example 2: Implementing Runnable interface
		        Thread t2 = new Thread(new MyRunnable());
		        t2.start();
		    }
		}

		// TODO Auto-generated method stub

	


