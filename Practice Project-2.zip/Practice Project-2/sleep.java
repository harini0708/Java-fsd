package com.projectphase1;

public class sleep {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	public class SleepExample {
		//    public static void main(String[] args) {
		        System.out.println("Start of the program");

		        try {
		            // Sleep for 2 seconds (2000 milliseconds)
		            Thread.sleep(2000);
		        } catch (InterruptedException e) {
		            e.printStackTrace();
		        }

		        System.out.println("End of the program");
		    }
		}
		