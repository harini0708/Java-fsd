package com.projectphase1;
import java.lang.Exception;

		class CustomException extends Exception {
		    public CustomException(String message) {
		        super(message);
		    }
		}

		public class throwsthrow {
		    // Method that throws a custom exception
		    public static void customExceptionMethod(int value) throws CustomException {
		        if (value < 0) {
		            throw new CustomException("Negative value not allowed");
		        }
		        System.out.println("Value is: " + value);
		    }

		    // Method with throws clause
		    public static void methodWithThrows() throws ArithmeticException {
		        int result = 10 / 0; // This will throw an ArithmeticException
		        System.out.println("Result: " + result);
		    }

		    public static void main(String[] args) {
		        try {
		            // Call method with throws clause
		            methodWithThrows();
		        } catch (ArithmeticException e) {
		            System.out.println("Caught an ArithmeticException: " + e.getMessage());
		        } finally {
		            System.out.println("Finally block executed");
		        }

		        try {
		            // Call method that throws a custom exception
		            customExceptionMethod(-5);
		        } catch (CustomException e) {
		            System.out.println("Caught a CustomException: " + e.getMessage());
		        } finally {
		            System.out.println("Finally block executed");
		        }
		    }
		}