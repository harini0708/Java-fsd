package com.projectphase1;
class Counter {
    private int count = 0;

    // Synchronized method to increment the count
    public synchronized void increment() {
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName() + " - Increment: " + (++count));
            try {
                Thread.sleep(100); // Simulating a time-consuming task
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class Synchronization {
    public static void main(String[] args) {
        Counter counter = new Counter();

        // Creating two threads that share the same Counter object
        Thread thread1 = new Thread(() -> counter.increment(), "Thread 1");
        Thread thread2 = new Thread(() -> counter.increment(), "Thread 2");

        // Start both threads
        thread1.start();
        thread2.start();
    }
}


