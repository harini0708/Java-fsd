package com.projectphase1;

public class trycatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
 	   int b=0;
       try {
    	   
    	   int c=a/b;
       }
    	catch(Exception e) {
    		System.out.print("can't divided by 0");
    		
    	}
       }
	}


