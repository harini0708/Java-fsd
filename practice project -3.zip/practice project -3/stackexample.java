package practiceproject1;

public class stackexample {
	  int[] s=new int[10];
  int tos;
  int data;
  stackexample(){
	
	    tos=-1;
  }
  void push(int val)
  {
	  if(tos==s.length) {
		  System.out.print("stack is full");
	  }
		  else {
	  s[++tos]=val;
  }
  }
   int pop() {
	  if(tos==-1) {
		  System.out.print("stack is empty");
	  }
	  return s[tos--];
  
   }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		stackexample stack=new stackexample();
		stack.push(5);
		stack.push(55);
		stack.push(53);
		stack.push(58);
		
		System.out.print(stack.pop());
		

	}

}
