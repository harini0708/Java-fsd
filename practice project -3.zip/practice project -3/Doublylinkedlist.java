package practiceproject1;

public class Doublylinkedlist {
	Node head;
	Node tail;
	class Node{
		Node next;
		Node pre;
		int data;
	
     
    	 Node(int valu){
    		 data=valu;
    		 next=null;
    		 
    	 }
     }
	Doublylinkedlist(){
		head=null;
		tail=null;
	}
     
	
	
  void add(int valu) {
	  Node newNode=new Node(valu);
	  newNode.next=head;
			  if(head==null) {
				  tail=newNode;
				  
			  }
			  else {
				  head.pre=newNode;
				  
				  
			  }
			head=newNode;  
	  
  }
 void addatend(int valu) {
	  Node newNode=new Node(valu);
	  newNode.pre=tail;
			  if(head==null) {
				  head=tail=newNode;
				  head.pre=null;
				  tail.next=null;
				  
			  }
			  else {
				  tail.next=newNode;
				  newNode.pre=tail;
				  tail=newNode;  
				  tail.next=null;
				  
				  
			  }
 }
  
	
  void displayright() {
	 Node temp=head;
	  while(temp!=null) {
		  System.out.println(temp.data);
		  temp=temp.next;
	  }
  }
	  void displayleft() {
		  Node temp=tail;
		  while(temp!=null) {
			  System.out.println(temp.data);
			  temp=temp.pre;
		  
	  }
	  
	  
  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Doublylinkedlist list=new Doublylinkedlist();
		list.add(5);
		list.add(15);
		list.add(25);
		list.add(35);
		list.add(45);
		list.add(55);
		
		System.out.println("travers from forward direction");
       list.displayright();
		System.out.println("travers from backward direction");

		 list.displayleft();
			System.out.println("adding data at end");

         list.addatend(100);
		 list.displayleft();
	}

}
