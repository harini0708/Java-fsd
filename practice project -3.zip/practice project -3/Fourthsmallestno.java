package practiceproject1;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class Fourthsmallestno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc=new Scanner(System.in);
    
   int[] n=new int[7];
		 for(int i=0;i<7;i++)
		 {
			n[i]= sc.nextInt();
		 }
		 Arrays.sort(n);
		 for(int i=0;i<7;i++)
		 {
			System.out.print(" "+n[i]);
		 }
		 System.out.println();
		System.out.println(n[3]);
		 
    
	}

}
