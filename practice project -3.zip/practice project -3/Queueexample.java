package practiceproject1;

import java.util.LinkedList;
import java.util.Queue;



public class Queueexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Queue<Integer> list=new LinkedList<>();
  list.add(5);
  list.add(25);
  list.add(53);
  list.add(58);
  list.add(59);
  System.out.println("print queue= "+list);
  System.out.println( list.peek());
  list.remove();
  System.out.println("after removing 1st element in  queue= "+list);
  System.out.println("size of queue"+list.size());
	}

}
