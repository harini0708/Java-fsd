package practiceproject1;
public class singlylinkedlist {

	Node head;
	class Node{
		int data;
		Node next;
		Node( int val){
			data=val;
		    next=null;
		    
		}
			}
	
	
	singlylinkedlist(){
		head=null;
		
	}
	
	public void addNode(int val) {
		Node newNode=new Node(val);
		if(head==null)
		{
			head=newNode;
		}
		 else
		   {
			   newNode.next=head;
			   head=newNode;
			   
		   }
	}
		
	

	void display() {
		Node temp=head;
		while(temp!=null) {
			System.out.println(temp.data);
			temp=temp.next;
		}
		
	}
	void delete() {
		if(head==null) {
			System.out.print("stack is empty");
		}
		head=head.next;
	}




	public static void main(String[] args) {
		// TODO Auto-generated method stub
		singlylinkedlist list=new singlylinkedlist();
       list.addNode(5);
       list.addNode(10);
       list.addNode(15);
       list.addNode(25);
       list.addNode(30); 
       list.addNode(35);
       list.display();
      list.delete();
     System.out.println("after deleting first element");
      list.display();
       
	}

}

