package practiceproject1;

public class circularlist {
	Node last;
	class Node{
		
		Node next;
		
		int data;
	
	 Node(int val){
		 data = val;
		 //head=null;
		 
	 }
	}
	circularlist(){
		last=null;
	}
	void setvalue(int val) {
		Node newNode=new Node(val);
		if(last==null)
		{
			newNode.next=newNode;
			last=newNode;
		}
		else {
			 
			 newNode.next=last.next;
			 last.next=newNode;
			
		}
	}
		private void display() {
			if(last==null)
				return;
			
			 Node temp=last.next;
			do {
				System.out.println(temp.data);
				temp=temp.next;
			}while(temp!=last.next);
				
				
			}
		
	
	
		// TODO Auto-generated method stub
		
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		circularlist list=new circularlist();
		list.setvalue(5);
		 list.setvalue(10);
		 list.setvalue(30);
		 list.setvalue(40);
		 list.setvalue(80);
		 list.display();
	}

}
